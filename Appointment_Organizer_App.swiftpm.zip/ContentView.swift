import SwiftUI

struct Appointment: Identifiable {
    let id = UUID()
    var title: String
    var date: Date
}

struct ContentView: View {
    @State private var appointmentTitle = ""
    @State private var appointmentDate = Date()
    @State private var appointments: [Appointment] = []
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("Appointment Organizer")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                
                TextField("Enter appointment name", text: $appointmentTitle)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)
                
                DatePicker("Select date and time", selection: $appointmentDate)
                    .padding(.horizontal)
                
                Button("Add Appointment") {
                    if !appointmentTitle.isEmpty {
                        let newAppointment = Appointment(
                            title: appointmentTitle,
                            date: appointmentDate
                        )
                        appointments.append(newAppointment)
                        appointmentTitle = ""
                    }
                }
                .buttonStyle(.borderedProminent)
                .tint(.pink)
                List {
                    ForEach(appointments) { appointment in
                        VStack(alignment: .leading) {
                            Text(appointment.title)
                                .font(.headline)
                            
                            Text(appointment.date, style: .date)
                            
                            Text(appointment.date, style: .time)
                                .foregroundColor(.gray)
                        }
                    }
                    .onDelete(perform: deleteAppointment)
                }
            }
            .padding()
        }
    }
    
    func deleteAppointment(at offsets: IndexSet) {
        appointments.remove(atOffsets: offsets)
    }
}
